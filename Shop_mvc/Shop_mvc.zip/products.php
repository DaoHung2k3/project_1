<?php
 include 'inc/header.php';
 include 'inc/slider.php';
?>

 <div class="main">
    <div class="content">
    	<div class="content_top">
    		<div class="heading">
    		<h3>Mới Nhất từ NIKE</h3>
    		</div>
    		<div class="clear"></div>
    	</div>
	      <div class="section group">
				<div class="grid_1_of_4 images_1_of_4">
					 <a href="details-3.php"><img src="images/Giay/G_1.png" alt="" /></a>
					 <h2>Boss Ton </h2>
					 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>
					 <p><span class="price">300.000 VNĐ</span></p>
				     <div class="button"><span><a href="details.php" class="details">Thông tin</a></span></div>
				</div>
				<div class="grid_1_of_4 images_1_of_4">
					<a href="details-2.php"><img src="images/Giay/G_2.png" alt="" /></a>
					 <h2>Tommy </h2>
					 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>
					 <p><span class="price">250.000 VNĐ</span></p> 
				     <div class="button"><span><a href="details.php" class="details">Thông tin</a></span></div>
				</div>
				<div class="grid_1_of_4 images_1_of_4">
					<a href="details-4.php"><img src="images/Giay/G_3.png" alt="" /></a>
					 <h2>Convert </h2>
					 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>
					 <p><span class="price">350.000 VNĐ</span></p>
				     <div class="button"><span><a href="details.php" class="details">Thông tin</a></span></div>
				</div>
				<div class="grid_1_of_4 images_1_of_4">
					<img src="images/Giay/G_4.jpg" alt="" />
					 <h2>NiKE </h2>
					 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit</p>
					 <p><span class="price">500.000 VNĐ</span></p> 
				     <div class="button"><span><a href="details.php" class="details">Thông tin</a></span></div>
				</div>
			</div>
			<div class="content_bottom">
    		<div class="heading">
    		<h3>Mới nhất từ Convert</h3>
    		</div>
    		<div class="clear"></div>
    	</div>
			<div class="section group">
				<div class="grid_1_of_4 images_1_of_4">
					 <a href="details-3.php"><img src="images/Giay/G_1.png" alt="" /></a>
					 <h2>Boss Ton </h2>
					 <p><span class="price">300.000 VNĐ</span></p>
				    
				     <div class="button"><span><a href="details.php" class="details">Thông tin</a></span></div>
				</div>
				<div class="grid_1_of_4 images_1_of_4">
					<a href="details-4.php"><img src="images/Giay/G_2.png" alt="" /></a>
					 <h2>Tommy </h2>
					 <p><span class="price">250.000 VNĐ</span></p>
				     <div class="button"><span><a href="details.php" class="details">Thông tin</a></span></div>
				</div>
				<div class="grid_1_of_4 images_1_of_4">
					<a href="details-2.php"><img src="images/Giay/G_3.png" alt="" /></a>
					 <h2>Convert </h2>
					 <p><span class="price">350.000 VNĐ</span></p>
				     <div class="button"><span><a href="details.php" class="details">Thông tin</a></span></div>
				</div>
				<div class="grid_1_of_4 images_1_of_4">
				 <img src="images/Giay/G_4.jpg" alt="" />
					 <h2>NiKE </h2>					 
					 <p><span class="price">500.000 VNĐ</span></p>   
				     <div class="button"><span><a href="details.php" class="details">Thông tin</a></span></div>
				</div>
			</div>
    </div>
 </div>

<?php
include 'inc/footer.php';
?>